import 'package:flutter/material.dart';

// const BASE_URL ="https://app.healthcrad.com/api/index.php/api/Mobile_app/";
const ProjectId = "smartlocker-22532";


Color scaffoldBackgroundColor = Colors.white;
Color backgroundColor = Color(0xffC4EBF2);
Color primaryColor = Color(0xff56C2A8);
Color secondaryBackgroundColor = Color(0xffF4F7F8);
Color facebookButtonColor = Color(0xff3b45c1);
Color textColor = Colors.black;
Color transparentColor = Colors.transparent;
Color disabledColor = Color(0xff7B7B7B);
Color starColor = Color(0xffffb910);
Color textFieldColor = Color(0xff7c7c7c);
Color lightGreyColor = Color(0xffacacac);
Color black2 = Color(0xff4d4d4d);
