package com.foundercodes.smartlocker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
